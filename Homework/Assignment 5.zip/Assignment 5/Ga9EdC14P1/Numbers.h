/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Numbers.h
 * Author: xWing
 *
 * Created on November 10, 2020, 10:07 PM
 */

#ifndef NUMBERS_H
#define NUMBERS_H
class Numbers{
    private:
    int number;
    public:
    void convert();
    void getnum();
};


#endif /* NUMBERS_H */

