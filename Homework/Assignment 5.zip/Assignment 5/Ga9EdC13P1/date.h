/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   date.h
 * Author: xWing
 *
 * Created on November 10, 2020, 6:21 PM
 */

#ifndef DATE_H
#define DATE_H
class Date
{
    private:
        int day;
        int month;
        int year;
    public:
        void getinfo();
        void prnt1();
        void prnt2();
        void prnt3();
};


#endif /* DATE_H */

