/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   sales.h
 * Author: Kevin Mai
 *
 * Created on October 15, 2020, 7:53 PM
 */

#ifndef SALES_H
#define SALES_H

struct sales
{
    string divN; // Division
    float qs[4]; // Quarter Sales
    float avgs; //Average Quarter Sales
    float annual; //Annual Sales
};


#endif /* SALES_H */

