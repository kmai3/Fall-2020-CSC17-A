/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   mobs.h
 * Author: xWing
 *
 * Created on October 24, 2020, 2:57 PM
 */
#include "bosses.h"
#ifndef MOBS_H
#define MOBS_H
struct Mobs{
    Boss *gob;
    Boss *skele;
    Boss *ogre;
    Boss *gskele;
    Boss *dmage;
    Boss *dragon;
    
};


#endif /* MOBS_H */

