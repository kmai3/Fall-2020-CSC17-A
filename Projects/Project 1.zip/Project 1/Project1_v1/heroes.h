/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   heroes.h
 * Author: xWing
 *
 * Created on October 24, 2020, 8:46 PM
 */

#ifndef HEROES_H
#define HEROES_H
enum Heroes{
    MAGEF , MAGEH, MAGEP, MAGEE, RANGEF, RANGEH, RANGEP, RANGEE, FIGHTF, 
    FIGHTH, FIGHTP, FIGHTE
};


#endif /* HEROES_H */

