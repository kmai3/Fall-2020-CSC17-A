/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   gg.h
 * Author: xWing
 *
 * Created on October 25, 2020, 2:22 PM
 */
#include "score.h"
#ifndef GG_H
#define GG_H
struct gg{
    Score *scores;
    int hp;
};


#endif /* GG_H */

