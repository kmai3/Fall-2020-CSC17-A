/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   info.h
 * Author: xWing
 *
 * Created on October 25, 2020, 3:53 PM
 */
#include <string>
#ifndef INFO_H
#define INFO_H
struct Info{
    string data; 
};


#endif /* INFO_H */

