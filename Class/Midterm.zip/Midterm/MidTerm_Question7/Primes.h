/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Primes.h
 * Author: xWing
 *
 * Created on October 22, 2020, 10:00 PM
 */
#include <string>
#ifndef PRIMES_H
#define PRIMES_H
struct Primes{
    unsigned char nPrimes;
    string m;
};



#endif /* PRIMES_H */

