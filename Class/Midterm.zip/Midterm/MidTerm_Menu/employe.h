/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * File:   employe.h
 * Author: xWing
 *
 * Created on October 20, 2020, 8:26 PM
 */
#include <string>
using namespace std;

#ifndef EMPLOYE_H
#define EMPLOYE_H
struct employee{
  string company;
  string address;
  string name;
  float payRate;
  float gp;
  unsigned short hrsWrkd;
};



#endif /* EMPLOYE_H */

