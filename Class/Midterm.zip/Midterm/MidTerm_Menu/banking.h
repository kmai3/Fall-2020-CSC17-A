/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   banking.h
 * Author: xWing
 *
 * Created on October 20, 2020, 12:57 PM
 */
#include <string>
using namespace std;

#ifndef BANKING_H
#define BANKING_H
struct Bank{
    
    string name; //Name of the Bank user
    string address; //The Address Given
    string account; //Account Number
};


#endif /* BANKING_H */

