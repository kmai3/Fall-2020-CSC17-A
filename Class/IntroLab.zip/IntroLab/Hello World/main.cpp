/* 
 * File:   main.cpp
 * Author: Kevin Mai
 * Created on September 1, 2020, 8:13 AM
 * Purpose: Hello World 
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std;

//User libraries 

//Global Constants Only
//Well Known Science, Mathematical and Laboratory Constants

//Function Prototypes 

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Display The Inputs/Outputs
   cout<<"Hello World"<<endl; 
    //Clean up the code, close files, deallocate memory, etc...
    //Exit stage right
    return 0;
}

